// ZaloXposed v3.0
// © 2026 Quang Bảo. Bảo lưu mọi quyền.
// Full UI overhaul • Theme system • Enhanced HUD • Professional structure
// Pure ObjC runtime — no Substrate. Compatible with Sideloadly / TrollStore.

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <mach/mach.h>

#pragma mark - Constants & Config

static NSString *const kPrefix = @"ZX3_";
static NSString *const kVersion = @"3.0";

static NSArray<NSString *> *ZXDefaultHosts(void) {
    return @[
        @"app-measurement.com",
        @"firebaselogging.googleapis.com",
        @"firebase-settings.crashlytics.com",
        @"crashlytics.com",
        @"google-analytics.com",
        @"analytics.google.com",
        @"pagead2.googlesyndication.com"
    ];
}

static BOOL ZXBool(NSString *k, BOOL def) {
    id v = [[NSUserDefaults standardUserDefaults] objectForKey:[kPrefix stringByAppendingString:k]];
    return v ? [v boolValue] : def;
}
static void ZXSetBool(NSString *k, BOOL v) {
    [[NSUserDefaults standardUserDefaults] setBool:v forKey:[kPrefix stringByAppendingString:k]];
}
static NSInteger ZXInt(NSString *k, NSInteger def) {
    id v = [[NSUserDefaults standardUserDefaults] objectForKey:[kPrefix stringByAppendingString:k]];
    return v ? [v integerValue] : def;
}
static void ZXSetInt(NSString *k, NSInteger v) {
    [[NSUserDefaults standardUserDefaults] setInteger:v forKey:[kPrefix stringByAppendingString:k]];
}
static NSArray *ZXHosts(void) {
    NSArray *a = [[NSUserDefaults standardUserDefaults] arrayForKey:@"ZX3_hosts"];
    return a ?: ZXDefaultHosts();
}
static void ZXSetHosts(NSArray *h) {
    [[NSUserDefaults standardUserDefaults] setObject:h forKey:@"ZX3_hosts"];
}

#pragma mark - Localization

static NSString *ZXL(NSString *key, NSString *fallback) {
    static NSBundle *b; static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *p = [[NSBundle mainBundle] pathForResource:@"ZaloXposedRes" ofType:@"bundle"];
        b = p ? [NSBundle bundleWithPath:p] : nil;
    });
    return b ? [b localizedStringForKey:key value:fallback table:@"Localizable"] : fallback;
}

#pragma mark - Logging (improved)

static NSString *ZXLogDir(void) {
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *dir = [docs stringByAppendingPathComponent:@"ZaloXposed"];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    return dir;
}
static NSString *ZXLogPath(void) {
    return [ZXLogDir() stringByAppendingPathComponent:@"log.txt"];
}

static void ZXLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1,2);
static void ZXLog(NSString *fmt, ...) {
    if (!ZXBool(@"log_enabled", YES)) return;
    va_list ap; va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    static dispatch_queue_t q; static dispatch_once_t once; static NSDateFormatter *df;
    dispatch_once(&once, ^{
        q = dispatch_queue_create("zx.log", DISPATCH_QUEUE_SERIAL);
        df = [NSDateFormatter new];
        df.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    });
    dispatch_async(q, ^{
        NSString *line = [NSString stringWithFormat:@"[%@] %@\n", [df stringFromDate:[NSDate date]], msg];
        NSString *path = ZXLogPath();
        NSFileManager *fm = [NSFileManager defaultManager];
        if (![fm fileExistsAtPath:path]) [fm createFileAtPath:path contents:nil attributes:nil];
        // Simple rotation: if > 1.5MB, truncate
        NSDictionary *attr = [fm attributesOfItemAtPath:path error:nil];
        if (attr.fileSize > 1.5 * 1024 * 1024) {
            [fm removeItemAtPath:path error:nil];
            [fm createFileAtPath:path contents:nil attributes:nil];
        }
        NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:path];
        [h seekToEndOfFile];
        [h writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
        [h closeFile];
    });
}

#pragma mark - Network Blocker

@interface ZXBlockProtocol : NSURLProtocol @end
@implementation ZXBlockProtocol
+ (BOOL)canInitWithRequest:(NSURLRequest *)r {
    if (!ZXBool(@"block_hosts", YES)) return NO;
    NSString *h = r.URL.host.lowercaseString;
    if (!h.length) return NO;
    for (NSString *b in ZXHosts()) {
        NSString *bl = b.lowercaseString;
        if (!bl.length) continue;
        if ([h isEqualToString:bl] || [h hasSuffix:[@"." stringByAppendingString:bl]]) return YES;
    }
    return NO;
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)r { return r; }
- (void)startLoading {
    ZXLog(@"blocked: %@", self.request.URL.host);
    [self.client URLProtocol:self didFailWithError:
        [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorNotConnectedToInternet userInfo:nil]];
}
- (void)stopLoading {}
@end

static void ZXPatchConfig(NSURLSessionConfiguration *c) {
    NSMutableArray *a = [NSMutableArray arrayWithObject:[ZXBlockProtocol class]];
    if (c.protocolClasses) [a addObjectsFromArray:c.protocolClasses];
    c.protocolClasses = a;
}

static NSURLSessionConfiguration *(*orig_default)(id, SEL);
static NSURLSessionConfiguration *new_default(id s, SEL c) {
    NSURLSessionConfiguration *x = orig_default(s, c); ZXPatchConfig(x); return x;
}
static NSURLSessionConfiguration *(*orig_ephemeral)(id, SEL);
static NSURLSessionConfiguration *new_ephemeral(id s, SEL c) {
    NSURLSessionConfiguration *x = orig_ephemeral(s, c); ZXPatchConfig(x); return x;
}

#pragma mark - Firebase

static void (*orig_fir_log)(id, SEL, NSString *, NSDictionary *);
static void new_fir_log(id self, SEL _cmd, NSString *name, NSDictionary *params) {
    if (ZXBool(@"disable_firebase", YES)) return;
    if (orig_fir_log) orig_fir_log(self, _cmd, name, params);
}

static void ZXInstallHooks(void) {
    static BOOL netDone = NO, firDone = NO;
    if (!netDone) {
        netDone = YES;
        [NSURLProtocol registerClass:[ZXBlockProtocol class]];
        Class cfg = [NSURLSessionConfiguration class];
        Method m1 = class_getClassMethod(cfg, @selector(defaultSessionConfiguration));
        if (m1) orig_default = (void *)method_setImplementation(m1, (IMP)new_default);
        Method m2 = class_getClassMethod(cfg, @selector(ephemeralSessionConfiguration));
        if (m2) orig_ephemeral = (void *)method_setImplementation(m2, (IMP)new_ephemeral);
        ZXLog(@"network hooks installed");
    }
    if (!firDone) {
        Class fir = objc_getClass("FIRAnalytics");
        if (fir) {
            Method m = class_getClassMethod(fir, @selector(logEventWithName:parameters:));
            if (m) {
                firDone = YES;
                orig_fir_log = (void *)method_setImplementation(m, (IMP)new_fir_log);
                ZXLog(@"FIRAnalytics hook installed");
            }
        }
    }
}

#pragma mark - Theme & Colors

typedef NS_ENUM(NSInteger, ZXTheme) {
    ZXThemeRainbow = 0,
    ZXThemeNeon,
    ZXThemeDark,
    ZXThemeSakura
};

static ZXTheme ZXCurrentTheme(void) {
    return (ZXTheme)ZXInt(@"theme", ZXThemeRainbow);
}

static UIColor *ZXHex(uint32_t h) {
    return [UIColor colorWithRed:((h>>16)&0xFF)/255.0 green:((h>>8)&0xFF)/255.0 blue:(h&0xFF)/255.0 alpha:1];
}

static NSArray<UIColor *> *ZXThemeColors(void) {
    switch (ZXCurrentTheme()) {
        case ZXThemeNeon:
            return @[ZXHex(0x00F5FF), ZXHex(0xFF00E5), ZXHex(0x00FF9F), ZXHex(0xFFEE00),
                     ZXHex(0x7B2FFF), ZXHex(0xFF2E63), ZXHex(0x00F5FF)];
        case ZXThemeDark:
            return @[ZXHex(0x8B5CF6), ZXHex(0x6366F1), ZXHex(0x3B82F6), ZXHex(0x06B6D4),
                     ZXHex(0x10B981), ZXHex(0x8B5CF6), ZXHex(0x6366F1)];
        case ZXThemeSakura:
            return @[ZXHex(0xFFB7C5), ZXHex(0xFF8FAB), ZXHex(0xFF6B9D), ZXHex(0xFF9EB5),
                     ZXHex(0xFFC2D1), ZXHex(0xFFB7C5), ZXHex(0xFF8FAB)];
        default: // Rainbow
            return @[ZXHex(0xFF3B30), ZXHex(0xFF9500), ZXHex(0xFFCC00), ZXHex(0x34C759),
                     ZXHex(0x0A84FF), ZXHex(0x5E5CE6), ZXHex(0xBF5AF2)];
    }
}

static NSArray *ZXThemeCG(void) {
    NSMutableArray *a = [NSMutableArray array];
    for (UIColor *c in ZXThemeColors()) [a addObject:(id)c.CGColor];
    [a addObject:(id)ZXThemeColors().firstObject.CGColor];
    return a;
}

static UIColor *ZXAccentColor(void) {
    return ZXThemeColors().firstObject;
}

#pragma mark - UI Helpers

static UIWindow *ZXKeyWindow(void) {
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if ([s isKindOfClass:[UIWindowScene class]] && s.activationState == UISceneActivationStateForegroundActive) {
            for (UIWindow *x in ((UIWindowScene *)s).windows) if (x.isKeyWindow) return x;
        }
    }
    return nil;
}
static UIViewController *ZXTopVC(void) {
    UIViewController *v = ZXKeyWindow().rootViewController;
    while (v.presentedViewController) v = v.presentedViewController;
    return v;
}

static CALayer *ZXAnimatedBorder(CGSize size, CGFloat radius, CGFloat width, BOOL animate) {
    CALayer *host = [CALayer layer];
    host.frame = CGRectMake(0, 0, size.width, size.height);
    CGFloat d = hypot(size.width, size.height);
    CAGradientLayer *g = [CAGradientLayer layer];
    g.type = kCAGradientLayerConic;
    g.colors = ZXThemeCG();
    g.startPoint = CGPointMake(0.5, 0.5);
    g.endPoint = CGPointMake(0.5, 0);
    g.bounds = CGRectMake(0, 0, d, d);
    g.position = CGPointMake(size.width/2, size.height/2);
    [host addSublayer:g];
    CAShapeLayer *m = [CAShapeLayer layer];
    m.frame = host.bounds;
    CGRect r = CGRectMake(width/2, width/2, size.width-width, size.height-width);
    m.path = [UIBezierPath bezierPathWithRoundedRect:r cornerRadius:MAX(0, radius - width/2)].CGPath;
    m.fillColor = NULL;
    m.strokeColor = UIColor.blackColor.CGColor;
    m.lineWidth = width;
    host.mask = m;
    if (animate) {
        CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        a.fromValue = @0; a.toValue = @(M_PI*2); a.duration = 5; a.repeatCount = HUGE_VALF;
        [g addAnimation:a forKey:@"spin"];
    }
    return host;
}

static NSAttributedString *ZXRainbowText(NSString *t, UIFont *font) {
    NSMutableAttributedString *as = [[NSMutableAttributedString alloc] initWithString:t];
    NSArray *cols = ZXThemeColors();
    for (NSUInteger i = 0; i < t.length; i++)
        [as addAttribute:NSForegroundColorAttributeName value:cols[i % cols.count] range:NSMakeRange(i, 1)];
    [as addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, t.length)];
    return as;
}

#pragma mark - HUD

static double ZXMemMB(void) {
    task_vm_info_data_t info;
    mach_msg_type_number_t c = TASK_VM_INFO_COUNT;
    if (task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&info, &c) == KERN_SUCCESS)
        return info.phys_footprint / 1048576.0;
    return 0;
}

@interface ZXHud : UIView
- (void)start; - (void)stop; - (void)applyTheme;
@end
static ZXHud *gHud;

@implementation ZXHud {
    UILabel *_info, *_credit;
    CADisplayLink *_link;
    CFTimeInterval _last;
    NSUInteger _frames;
    int _fps;
    NSDateFormatter *_df;
}
- (instancetype)init {
    self = [super initWithFrame:CGRectMake(12, 54, 160, 88)];
    self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.72];
    self.layer.cornerRadius = 14;
    self.layer.borderWidth = 1.0;
    self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.18].CGColor;
    self.clipsToBounds = YES;
    _info = [UILabel new]; _info.numberOfLines = 0;
    _credit = [UILabel new];
    _credit.attributedText = ZXRainbowText(@"© Quang Bảo", [UIFont systemFontOfSize:9 weight:UIFontWeightHeavy]);
    [self addSubview:_info]; [self addSubview:_credit];
    _df = [NSDateFormatter new];
    _df.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    _df.dateFormat = @"dd/MM HH:mm:ss";
    [self addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
    [self refresh];
    return self;
}
- (void)applyTheme {
    _credit.attributedText = ZXRainbowText(@"© Quang Bảo", [UIFont systemFontOfSize:9 weight:UIFontWeightHeavy]);
    self.layer.borderColor = [ZXAccentColor() colorWithAlphaComponent:0.45].CGColor;
}
- (void)start {
    if (_link) return;
    _last = 0; _frames = 0;
    _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick:)];
    [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}
- (void)stop { [_link invalidate]; _link = nil; }
- (void)tick:(CADisplayLink *)l {
    if (_last == 0) { _last = l.timestamp; return; }
    _frames++;
    CFTimeInterval dt = l.timestamp - _last;
    if (dt >= 0.5) {
        _fps = (int)round(_frames / dt);
        _frames = 0; _last = l.timestamp;
        [self refresh];
    }
}
- (void)refresh {
    UIFont *f = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightSemibold];
    NSMutableAttributedString *out = [NSMutableAttributedString new];
    void (^add)(NSString *, UIColor *) = ^(NSString *line, UIColor *c) {
        if (out.length) [out appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n"]];
        [out appendAttributedString:[[NSAttributedString alloc] initWithString:line
            attributes:@{NSFontAttributeName:f, NSForegroundColorAttributeName:c}]];
    };
    if (ZXBool(@"hud_fps", YES)) {
        UIColor *c = _fps >= 55 ? ZXHex(0x34C759) : (_fps >= 40 ? ZXHex(0xFFCC00) : ZXHex(0xFF3B30));
        add([NSString stringWithFormat:@"FPS  %d", _fps], c);
    }
    if (ZXBool(@"hud_time", YES)) add([_df stringFromDate:[NSDate date]], UIColor.whiteColor);
    if (ZXBool(@"hud_mem", YES)) add([NSString stringWithFormat:@"RAM  %.0f MB", ZXMemMB()], UIColor.whiteColor);
    if (ZXBool(@"hud_battery", YES)) {
        [UIDevice currentDevice].batteryMonitoringEnabled = YES;
        float bat = [UIDevice currentDevice].batteryLevel;
        if (bat >= 0) {
            UIColor *bc = bat > 0.5 ? ZXHex(0x34C759) : (bat > 0.2 ? ZXHex(0xFFCC00) : ZXHex(0xFF3B30));
            add([NSString stringWithFormat:@"BAT  %.0f%%", bat * 100], bc);
        }
    }
    _info.attributedText = out;
    CGSize s1 = out.length ? [_info sizeThatFits:CGSizeMake(280, CGFLOAT_MAX)] : CGSizeZero;
    CGSize s2 = [_credit sizeThatFits:CGSizeMake(280, CGFLOAT_MAX)];
    CGFloat w = MAX(s1.width, s2.width) + 18;
    _info.frame = CGRectMake(9, 7, w - 18, s1.height);
    _credit.frame = CGRectMake(9, CGRectGetMaxY(_info.frame) + 3, w - 18, s2.height);
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, w, CGRectGetMaxY(_credit.frame) + 8);
}
- (void)pan:(UIPanGestureRecognizer *)g {
    CGPoint t = [g translationInView:self.superview];
    self.center = CGPointMake(self.center.x + t.x, self.center.y + t.y);
    [g setTranslation:CGPointZero inView:self.superview];
}
@end

#pragma mark - Screen Border

@interface ZXScreenBorder : UIView
+ (void)sync;
@end
static ZXScreenBorder *gBorder;

@implementation ZXScreenBorder {
    CALayer *_borderLayer;
}
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    self.userInteractionEnabled = NO;
    self.backgroundColor = UIColor.clearColor;
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    [_borderLayer removeFromSuperlayer];
    _borderLayer = ZXAnimatedBorder(self.bounds.size, 0, 3.5, ZXBool(@"rainbow_anim", YES));
    [self.layer addSublayer:_borderLayer];
}
+ (void)sync {
    BOOL on = ZXBool(@"screen_border", YES);
    if (on) {
        if (!gBorder) {
            UIWindow *w = ZXKeyWindow();
            if (!w) return;
            gBorder = [[ZXScreenBorder alloc] initWithFrame:w.bounds];
            gBorder.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            [w addSubview:gBorder];
        }
        [gBorder setNeedsLayout];
        gBorder.hidden = NO;
    } else {
        gBorder.hidden = YES;
    }
}
@end

#pragma mark - Floating Button

@interface ZXFloatButton : UIView
@end
static ZXFloatButton *gFloat;

@implementation ZXFloatButton {
    UILabel *_lab;
    CALayer *_glow;
}
- (instancetype)init {
    self = [super initWithFrame:CGRectMake(0, 0, 52, 52)];
    self.backgroundColor = [UIColor colorWithWhite:0.08 alpha:0.92];
    self.layer.cornerRadius = 26;
    self.layer.borderWidth = 1.5;
    self.layer.borderColor = [ZXAccentColor() colorWithAlphaComponent:0.7].CGColor;
    _lab = [UILabel new];
    _lab.text = @"Z";
    _lab.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBlack];
    _lab.textColor = UIColor.whiteColor;
    _lab.textAlignment = NSTextAlignmentCenter;
    _lab.frame = self.bounds;
    [self addSubview:_lab];
    // glow
    _glow = [CALayer layer];
    _glow.frame = CGRectInset(self.bounds, -6, -6);
    _glow.cornerRadius = 32;
    _glow.backgroundColor = [ZXAccentColor() colorWithAlphaComponent:0.25].CGColor;
    [self.layer insertSublayer:_glow atIndex:0];
    [self addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
    [self addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)]];
    return self;
}
- (void)applyTheme {
    self.layer.borderColor = [ZXAccentColor() colorWithAlphaComponent:0.7].CGColor;
    _glow.backgroundColor = [ZXAccentColor() colorWithAlphaComponent:0.25].CGColor;
}
- (void)pan:(UIPanGestureRecognizer *)g {
    CGPoint t = [g translationInView:self.superview];
    self.center = CGPointMake(self.center.x + t.x, self.center.y + t.y);
    [g setTranslation:CGPointZero inView:self.superview];
}
- (void)tap {
    // Will be set by menu
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ZXOpenMenu" object:nil];
}
@end

static void ZXSyncFloat(void) {
    BOOL on = ZXBool(@"floating_button", YES);
    if (on) {
        if (!gFloat) {
            UIWindow *w = ZXKeyWindow();
            if (!w) return;
            gFloat = [ZXFloatButton new];
            gFloat.center = CGPointMake(w.bounds.size.width - 40, w.bounds.size.height * 0.55);
            [w addSubview:gFloat];
        }
        [gFloat applyTheme];
        gFloat.hidden = NO;
    } else {
        gFloat.hidden = YES;
    }
}

#pragma mark - Menu

@interface ZXMenuView : UIView
+ (void)show;
+ (void)hide;
@end
static ZXMenuView *gMenu;

@implementation ZXMenuView {
    UIView *_panel;
    UIScrollView *_scroll;
    UIStackView *_stack;
    UIView *_pane;
    UITextView *_paneText;
    void (^_saveBlock)(NSString *);
    CALayer *_borderLayer;
}

+ (void)show {
    if (gMenu) return;
    UIWindow *w = ZXKeyWindow();
    if (!w) return;
    gMenu = [[ZXMenuView alloc] initWithFrame:w.bounds];
    [w addSubview:gMenu];
    [gMenu appear];
}
+ (void)hide {
    [gMenu disappear];
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.45];
    
    // Blur background
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark];
    UIVisualEffectView *blurV = [[UIVisualEffectView alloc] initWithEffect:blur];
    blurV.frame = self.bounds;
    blurV.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self addSubview:blurV];
    
    UITapGestureRecognizer *bgTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bgTap)];
    [self addGestureRecognizer:bgTap];
    
    CGFloat pw = MIN(340, frame.size.width - 28);
    CGFloat ph = MIN(580, frame.size.height - 80);
    _panel = [[UIView alloc] initWithFrame:CGRectMake((frame.size.width-pw)/2, (frame.size.height-ph)/2, pw, ph)];
    _panel.backgroundColor = [UIColor colorWithWhite:0.07 alpha:0.92];
    _panel.layer.cornerRadius = 22;
    _panel.clipsToBounds = YES;
    [self addSubview:_panel];
    
    // Header
    UILabel *title = [UILabel new];
    title.attributedText = ZXRainbowText(@"ZaloXposed", [UIFont systemFontOfSize:20 weight:UIFontWeightHeavy]);
    title.frame = CGRectMake(18, 16, pw - 70, 28);
    [_panel addSubview:title];
    
    UILabel *ver = [UILabel new];
    ver.text = [NSString stringWithFormat:@"v%@", kVersion];
    ver.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightMedium];
    ver.textColor = [UIColor colorWithWhite:1 alpha:0.5];
    ver.frame = CGRectMake(pw - 58, 20, 42, 20);
    ver.textAlignment = NSTextAlignmentRight;
    [_panel addSubview:ver];
    
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    [close setTitle:@"✕" forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightBold];
    [close setTitleColor:[UIColor colorWithWhite:1 alpha:0.7] forState:UIControlStateNormal];
    close.frame = CGRectMake(pw - 44, 12, 36, 36);
    [close addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
    [_panel addSubview:close];
    
    _scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 52, pw, ph - 52)];
    _scroll.showsVerticalScrollIndicator = YES;
    _scroll.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    [_panel addSubview:_scroll];
    
    _stack = [UIStackView new];
    _stack.axis = UILayoutConstraintAxisVertical;
    _stack.spacing = 10;
    _stack.translatesAutoresizingMaskIntoConstraints = NO;
    [_scroll addSubview:_stack];
    [NSLayoutConstraint activateConstraints:@[
        [_stack.topAnchor constraintEqualToAnchor:_scroll.contentLayoutGuide.topAnchor constant:4],
        [_stack.bottomAnchor constraintEqualToAnchor:_scroll.contentLayoutGuide.bottomAnchor constant:-20],
        [_stack.leadingAnchor constraintEqualToAnchor:_scroll.contentLayoutGuide.leadingAnchor constant:14],
        [_stack.trailingAnchor constraintEqualToAnchor:_scroll.contentLayoutGuide.trailingAnchor constant:-14],
        [_stack.widthAnchor constraintEqualToAnchor:_scroll.frameLayoutGuide.widthAnchor constant:-28],
    ]];
    
    [self buildContent];
    
    // Border on top
    _borderLayer = ZXAnimatedBorder(CGSizeMake(pw, ph), 22, 2.8, ZXBool(@"rainbow_anim", YES));
    [_panel.layer addSublayer:_borderLayer];
    
    return self;
}

- (void)appear {
    _panel.transform = CGAffineTransformMakeScale(0.88, 0.88);
    _panel.alpha = 0;
    self.alpha = 0;
    [UIView animateWithDuration:0.28 delay:0 usingSpringWithDamping:0.78 initialSpringVelocity:0.6 options:0 animations:^{
        self.alpha = 1;
        self->_panel.transform = CGAffineTransformIdentity;
        self->_panel.alpha = 1;
    } completion:nil];
}
- (void)disappear {
    [UIView animateWithDuration:0.2 animations:^{
        self.alpha = 0;
        self->_panel.transform = CGAffineTransformMakeScale(0.92, 0.92);
    } completion:^(BOOL f) {
        [self removeFromSuperview];
        gMenu = nil;
    }];
}
- (void)bgTap { [self close]; }
- (void)close { [ZXMenuView hide]; }

#pragma mark Build content

- (void)buildContent {
    // Disclaimer first
    [self addSection:ZXL(@"section_disclaimer", @"Tuyên bố miễn trừ") rows:@[
        [self infoRow:ZXL(@"disclaimer_text", @"ZaloXposed chỉ phục vụ mục đích bảo vệ quyền riêng tư cá nhân và nghiên cứu. Không hỗ trợ vượt captcha, tạo tài khoản hàng loạt hay các hành vi vi phạm điều khoản dịch vụ. Người dùng tự chịu trách nhiệm hoàn toàn khi sử dụng.")]
    ]];
    
    [self addSection:ZXL(@"section_tracking", @"Chống theo dõi") rows:@[
        [self toggleKey:@"disable_firebase" title:ZXL(@"disable_firebase", @"Tắt Firebase Analytics")
                    sub:ZXL(@"disable_firebase_desc", @"Không ghi và gửi sự kiện phân tích") def:YES],
        [self toggleKey:@"block_hosts" title:ZXL(@"block_hosts", @"Chặn theo tên miền")
                    sub:ZXL(@"block_hosts_desc", @"Chặn các máy chủ trong danh sách") def:YES],
        [self buttonId:@"edit_hosts" title:[@"✎  " stringByAppendingString:ZXL(@"edit_hosts", @"Sửa danh sách tên miền")] color:ZXHex(0x0A84FF)],
    ]];
    
    [self addSection:ZXL(@"section_theme", @"Giao diện chủ đề") rows:@[
        [self themeButton:ZXThemeRainbow title:ZXL(@"theme_rainbow", @"Rainbow (7 màu)")],
        [self themeButton:ZXThemeNeon title:ZXL(@"theme_neon", @"Neon Cyber")],
        [self themeButton:ZXThemeDark title:ZXL(@"theme_dark", @"Dark Premium")],
        [self themeButton:ZXThemeSakura title:ZXL(@"theme_sakura", @"Cherry Blossom")],
    ]];
    
    [self addSection:ZXL(@"section_ui", @"Giao diện") rows:@[
        [self toggleKey:@"screen_border" title:ZXL(@"screen_border", @"Viền màn hình")
                    sub:ZXL(@"screen_border_desc", @"Viền chạy quanh toàn màn hình Zalo") def:YES],
        [self toggleKey:@"floating_button" title:ZXL(@"floating_button", @"Nút nổi Z")
                    sub:ZXL(@"floating_button_desc", @"Nút kéo thả để mở menu") def:YES],
        [self toggleKey:@"rainbow_anim" title:ZXL(@"rainbow_anim", @"Animation viền")
                    sub:ZXL(@"rainbow_anim_desc", @"Viền chuyển động liên tục") def:YES],
    ]];
    
    [self addSection:ZXL(@"section_hud", @"Bảng thông tin") rows:@[
        [self toggleKey:@"hud_enabled" title:ZXL(@"hud_enabled", @"Bật bảng thông tin")
                    sub:ZXL(@"hud_enabled_desc", @"Hiện góc màn hình, kéo thả được") def:YES],
        [self toggleKey:@"hud_fps" title:ZXL(@"hud_fps", @"Đo FPS") sub:@"Xanh ≥55 • Vàng ≥40 • Đỏ thấp hơn" def:YES],
        [self toggleKey:@"hud_time" title:ZXL(@"hud_time", @"Ngày giờ thực") sub:@"Cập nhật liên tục" def:YES],
        [self toggleKey:@"hud_mem" title:ZXL(@"hud_mem", @"RAM đang dùng") sub:@"Bộ nhớ Zalo đang chiếm" def:YES],
        [self toggleKey:@"hud_battery" title:ZXL(@"hud_battery", @"Phần trăm pin") sub:@"Màu theo mức pin" def:YES],
    ]];
    
    [self addSection:ZXL(@"section_logs", @"Nhật ký") rows:@[
        [self toggleKey:@"log_enabled" title:ZXL(@"log_enabled", @"Ghi nhật ký") sub:@"Lưu hoạt động vào log.txt" def:YES],
        [self buttonId:@"log_view" title:[@"☰  " stringByAppendingString:ZXL(@"log_view", @"Xem nhật ký")] color:ZXHex(0x0A84FF)],
        [self buttonId:@"log_export" title:[@"⇪  " stringByAppendingString:ZXL(@"log_export", @"Xuất nhật ký")] color:ZXHex(0x0A84FF)],
        [self buttonId:@"log_clear" title:[@"⌫  " stringByAppendingString:ZXL(@"log_clear", @"Xóa nhật ký")] color:ZXHex(0xFF453A)],
    ]];
    
    [self addSection:ZXL(@"section_advanced", @"Nâng cao") rows:@[
        [self buttonId:@"export_set" title:[@"⇪  " stringByAppendingString:ZXL(@"export_settings", @"Xuất cài đặt")] color:ZXHex(0x34C759)],
        [self buttonId:@"import_set" title:[@"⇩  " stringByAppendingString:ZXL(@"import_settings", @"Nhập cài đặt")] color:ZXHex(0x34C759)],
        [self buttonId:@"reset" title:[@"↺  " stringByAppendingString:ZXL(@"reset_settings", @"Đặt lại mặc định")] color:ZXHex(0xFF453A)],
    ]];
    
    [self addSection:ZXL(@"section_about", @"Thông tin") rows:@[
        [self infoRow:ZXL(@"about_text", @"ZaloXposed v3.0\n© 2026 Quang Bảo\nBảo lưu mọi quyền.")],
        [self infoRow:ZXL(@"gesture_hint", @"Chạm 2 lần bằng 3 ngón tay để mở/đóng menu")],
    ]];
}

- (UIView *)toggleKey:(NSString *)key title:(NSString *)title sub:(NSString *)sub def:(BOOL)def {
    UIView *row = [UIView new];
    row.backgroundColor = [UIColor colorWithWhite:1 alpha:0.06];
    row.layer.cornerRadius = 12;
    
    UILabel *t = [UILabel new];
    t.text = title;
    t.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    t.textColor = UIColor.whiteColor;
    t.translatesAutoresizingMaskIntoConstraints = NO;
    
    UILabel *s = [UILabel new];
    s.text = sub;
    s.font = [UIFont systemFontOfSize:12];
    s.textColor = [UIColor colorWithWhite:1 alpha:0.45];
    s.numberOfLines = 2;
    s.translatesAutoresizingMaskIntoConstraints = NO;
    
    UISwitch *sw = [UISwitch new];
    sw.on = ZXBool(key, def);
    sw.onTintColor = ZXAccentColor();
    sw.translatesAutoresizingMaskIntoConstraints = NO;
    [sw addTarget:self action:@selector(toggleChanged:) forControlEvents:UIControlEventValueChanged];
    objc_setAssociatedObject(sw, "zx_key", key, OBJC_ASSOCIATION_COPY_NONATOMIC);
    
    [row addSubview:t]; [row addSubview:s]; [row addSubview:sw];
    [NSLayoutConstraint activateConstraints:@[
        [t.topAnchor constraintEqualToAnchor:row.topAnchor constant:10],
        [t.leadingAnchor constraintEqualToAnchor:row.leadingAnchor constant:14],
        [t.trailingAnchor constraintEqualToAnchor:sw.leadingAnchor constant:-10],
        [s.topAnchor constraintEqualToAnchor:t.bottomAnchor constant:2],
        [s.leadingAnchor constraintEqualToAnchor:t.leadingAnchor],
        [s.trailingAnchor constraintEqualToAnchor:t.trailingAnchor],
        [s.bottomAnchor constraintEqualToAnchor:row.bottomAnchor constant:-10],
        [sw.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
        [sw.trailingAnchor constraintEqualToAnchor:row.trailingAnchor constant:-12],
    ]];
    return row;
}

- (UIView *)buttonId:(NSString *)ident title:(NSString *)title color:(UIColor *)c {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:c forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    b.backgroundColor = [UIColor colorWithWhite:1 alpha:0.06];
    b.layer.cornerRadius = 12;
    b.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    b.contentEdgeInsets = UIEdgeInsetsMake(14, 14, 14, 14);
    [b addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    objc_setAssociatedObject(b, "zx_id", ident, OBJC_ASSOCIATION_COPY_NONATOMIC);
    return b;
}

- (UIView *)themeButton:(ZXTheme)theme title:(NSString *)title {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    BOOL selected = (ZXCurrentTheme() == theme);
    [b setTitle:[NSString stringWithFormat:@"%@  %@", selected ? @"●" : @"○", title] forState:UIControlStateNormal];
    [b setTitleColor:selected ? ZXAccentColor() : UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont systemFontOfSize:15 weight:selected ? UIFontWeightBold : UIFontWeightMedium];
    b.backgroundColor = [UIColor colorWithWhite:1 alpha:selected ? 0.12 : 0.06];
    b.layer.cornerRadius = 12;
    b.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    b.contentEdgeInsets = UIEdgeInsetsMake(13, 14, 13, 14);
    [b addTarget:self action:@selector(themeTapped:) forControlEvents:UIControlEventTouchUpInside];
    objc_setAssociatedObject(b, "zx_theme", @(theme), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return b;
}

- (UIView *)infoRow:(NSString *)text {
    UILabel *l = [UILabel new];
    l.text = text;
    l.font = [UIFont systemFontOfSize:13];
    l.textColor = [UIColor colorWithWhite:1 alpha:0.55];
    l.numberOfLines = 0;
    l.backgroundColor = [UIColor colorWithWhite:1 alpha:0.04];
    l.layer.cornerRadius = 12;
    l.clipsToBounds = YES;
    // padding via container
    UIView *box = [UIView new];
    box.backgroundColor = [UIColor colorWithWhite:1 alpha:0.04];
    box.layer.cornerRadius = 12;
    l.translatesAutoresizingMaskIntoConstraints = NO;
    [box addSubview:l];
    [NSLayoutConstraint activateConstraints:@[
        [l.topAnchor constraintEqualToAnchor:box.topAnchor constant:12],
        [l.bottomAnchor constraintEqualToAnchor:box.bottomAnchor constant:-12],
        [l.leadingAnchor constraintEqualToAnchor:box.leadingAnchor constant:14],
        [l.trailingAnchor constraintEqualToAnchor:box.trailingAnchor constant:-14],
    ]];
    return box;
}

- (void)addSection:(NSString *)title rows:(NSArray<UIView *> *)rows {
    UILabel *h = [UILabel new];
    h.text = title.uppercaseString;
    h.font = [UIFont systemFontOfSize:12 weight:UIFontWeightBold];
    h.textColor = [UIColor colorWithWhite:1 alpha:0.4];
    [_stack addArrangedSubview:h];
    for (UIView *r in rows) [_stack addArrangedSubview:r];
}

#pragma mark Actions

- (void)toggleChanged:(UISwitch *)sw {
    NSString *key = objc_getAssociatedObject(sw, "zx_key");
    if (!key) return;
    ZXSetBool(key, sw.on);
    ZXLog(@"setting %@ = %d", key, sw.on);
    if ([key isEqualToString:@"screen_border"] || [key isEqualToString:@"rainbow_anim"]) [ZXScreenBorder sync];
    if ([key isEqualToString:@"floating_button"]) ZXSyncFloat();
    if ([key hasPrefix:@"hud_"]) {
        if (ZXBool(@"hud_enabled", YES)) {
            if (!gHud) {
                gHud = [ZXHud new];
                [ZXKeyWindow() addSubview:gHud];
                [gHud start];
            }
            gHud.hidden = NO;
            [gHud applyTheme];
            [gHud refresh];
        } else {
            gHud.hidden = YES;
            [gHud stop];
        }
    }
    [self toast:ZXL(@"toast_saved", @"Đã lưu cài đặt")];
}

- (void)themeTapped:(UIButton *)b {
    NSNumber *n = objc_getAssociatedObject(b, "zx_theme");
    if (!n) return;
    ZXSetInt(@"theme", n.integerValue);
    ZXLog(@"theme changed to %ld", (long)n.integerValue);
    // Rebuild border & float & hud
    [ZXScreenBorder sync];
    ZXSyncFloat();
    if (gHud) [gHud applyTheme];
    // Rebuild menu content for selection state
    for (UIView *v in _stack.arrangedSubviews) [v removeFromSuperview];
    [self buildContent];
    // Refresh border color
    [_borderLayer removeFromSuperlayer];
    _borderLayer = ZXAnimatedBorder(_panel.bounds.size, 22, 2.8, ZXBool(@"rainbow_anim", YES));
    [_panel.layer addSublayer:_borderLayer];
    [self toast:ZXL(@"toast_saved", @"Đã lưu cài đặt")];
}

- (void)buttonTapped:(UIButton *)b {
    NSString *ident = objc_getAssociatedObject(b, "zx_id");
    if (!ident) return;
    
    if ([ident isEqualToString:@"edit_hosts"]) {
        [self openPane:@"Danh sách domain (mỗi dòng một domain)" text:[ZXHosts() componentsJoinedByString:@"\n"] save:^(NSString *t) {
            NSMutableArray *arr = [NSMutableArray array];
            for (NSString *line in [t componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
                NSString *s = [line stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                if (s.length) [arr addObject:s];
            }
            if (arr.count) ZXSetHosts(arr);
        }];
    }
    else if ([ident isEqualToString:@"log_view"]) {
        NSString *log = [NSString stringWithContentsOfFile:ZXLogPath() encoding:NSUTF8StringEncoding error:nil] ?: ZXL(@"log_empty", @"Chưa có nhật ký");
        [self openPane:@"Nhật ký" text:log save:nil];
    }
    else if ([ident isEqualToString:@"log_export"]) {
        NSString *path = ZXLogPath();
        if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
            UIActivityViewController *ac = [[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:path]] applicationActivities:nil];
            [ZXTopVC() presentViewController:ac animated:YES completion:nil];
            [self toast:ZXL(@"toast_exported", @"Đã xuất")];
        } else {
            [self toast:ZXL(@"log_empty", @"Chưa có nhật ký")];
        }
    }
    else if ([ident isEqualToString:@"log_clear"]) {
        [[NSFileManager defaultManager] removeItemAtPath:ZXLogPath() error:nil];
        [self toast:ZXL(@"toast_cleared", @"Đã xóa nhật ký")];
    }
    else if ([ident isEqualToString:@"reset"]) {
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Xác nhận" message:@"Đặt lại toàn bộ cài đặt về mặc định?" preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"Hủy" style:UIAlertActionStyleCancel handler:nil]];
        [a addAction:[UIAlertAction actionWithTitle:@"Đặt lại" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *_) {
            NSString *prefix = kPrefix;
            NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
            for (NSString *k in d.dictionaryRepresentation.allKeys) {
                if ([k hasPrefix:prefix] || [k isEqualToString:@"ZX3_hosts"]) [d removeObjectForKey:k];
            }
            [self toast:ZXL(@"toast_reset", @"Đã đặt lại mặc định")];
            [ZXMenuView hide];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [ZXMenuView show];
            });
        }]];
        [ZXTopVC() presentViewController:a animated:YES completion:nil];
    }
    else if ([ident isEqualToString:@"export_set"]) {
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        for (NSString *k in d.dictionaryRepresentation.allKeys) {
            if ([k hasPrefix:kPrefix] || [k isEqualToString:@"ZX3_hosts"]) dict[k] = [d objectForKey:k];
        }
        NSData *data = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:nil];
        NSString *path = [ZXLogDir() stringByAppendingPathComponent:@"settings.json"];
        [data writeToFile:path atomically:YES];
        UIActivityViewController *ac = [[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:path]] applicationActivities:nil];
        [ZXTopVC() presentViewController:ac animated:YES completion:nil];
        [self toast:ZXL(@"toast_exported", @"Đã xuất")];
    }
    else if ([ident isEqualToString:@"import_set"]) {
        // Simple: user pastes JSON in a pane (for pure runtime no file picker easy)
        [self openPane:@"Dán nội dung settings.json vào đây rồi bấm Lưu" text:@"" save:^(NSString *t) {
            NSData *data = [t dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            if (![dict isKindOfClass:[NSDictionary class]]) {
                [self toast:@"JSON không hợp lệ"];
                return;
            }
            NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
            for (NSString *k in dict) {
                if ([k hasPrefix:kPrefix] || [k isEqualToString:@"ZX3_hosts"]) [d setObject:dict[k] forKey:k];
            }
            [self toast:ZXL(@"toast_imported", @"Đã nhập cài đặt")];
            [ZXMenuView hide];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [ZXMenuView show];
                [ZXScreenBorder sync];
                ZXSyncFloat();
            });
        }];
    }
}

- (void)openPane:(NSString *)title text:(NSString *)text save:(void(^)(NSString *))save {
    if (_pane) [_pane removeFromSuperview];
    CGFloat pw = _panel.bounds.size.width;
    CGFloat ph = _panel.bounds.size.height;
    UIView *p = [[UIView alloc] initWithFrame:CGRectMake(0, 0, pw, ph)];
    p.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.98];
    p.layer.cornerRadius = 22;
    
    UILabel *t = [UILabel new];
    t.text = title;
    t.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
    t.textColor = UIColor.whiteColor;
    t.frame = CGRectMake(16, 14, pw - 100, 24);
    [p addSubview:t];
    
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    [close setTitle:@"Đóng" forState:UIControlStateNormal];
    [close setTitleColor:[UIColor colorWithWhite:1 alpha:0.7] forState:UIControlStateNormal];
    close.frame = CGRectMake(pw - 70, 10, 56, 32);
    [close addTarget:self action:@selector(closePane) forControlEvents:UIControlEventTouchUpInside];
    [p addSubview:close];
    
    _paneText = [[UITextView alloc] initWithFrame:CGRectMake(12, 50, pw - 24, ph - 110)];
    _paneText.text = text;
    _paneText.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular];
    _paneText.textColor = UIColor.whiteColor;
    _paneText.backgroundColor = [UIColor colorWithWhite:0.12 alpha:1];
    _paneText.layer.cornerRadius = 10;
    _paneText.editable = (save != nil);
    [p addSubview:_paneText];
    
    if (save) {
        _saveBlock = [save copy];
        UIButton *sv = [UIButton buttonWithType:UIButtonTypeSystem];
        [sv setTitle:@"Lưu" forState:UIControlStateNormal];
        [sv setTitleColor:ZXAccentColor() forState:UIControlStateNormal];
        sv.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
        sv.frame = CGRectMake(12, ph - 52, pw - 24, 40);
        [sv addTarget:self action:@selector(savePane) forControlEvents:UIControlEventTouchUpInside];
        [p addSubview:sv];
    }
    [_panel addSubview:p];
    _pane = p;
    // bring border to front
    for (CALayer *ly in [_panel.layer.sublayers copy]) {
        if (ly.mask && ly.sublayers.count == 1 && [ly.sublayers.firstObject isKindOfClass:[CAGradientLayer class]]) {
            [ly removeFromSuperlayer]; [_panel.layer addSublayer:ly];
        }
    }
}
- (void)closePane { [_pane removeFromSuperview]; _pane = nil; _saveBlock = nil; [self endEditing:YES]; }
- (void)savePane {
    if (_saveBlock) _saveBlock(_paneText.text);
    [self closePane];
    [self toast:ZXL(@"toast_saved", @"Đã lưu cài đặt")];
}

- (void)toast:(NSString *)msg {
    UILabel *t = [UILabel new];
    t.text = msg;
    t.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    t.textColor = UIColor.whiteColor;
    t.backgroundColor = [UIColor colorWithWhite:0.15 alpha:0.92];
    t.textAlignment = NSTextAlignmentCenter;
    t.layer.cornerRadius = 10;
    t.clipsToBounds = YES;
    CGSize s = [t sizeThatFits:CGSizeMake(280, 40)];
    t.frame = CGRectMake((_panel.bounds.size.width - s.width - 28)/2, _panel.bounds.size.height - 70, s.width + 28, 36);
    t.alpha = 0;
    [_panel addSubview:t];
    [UIView animateWithDuration:0.2 animations:^{ t.alpha = 1; } completion:^(BOOL f) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [UIView animateWithDuration:0.25 animations:^{ t.alpha = 0; } completion:^(BOOL f2) { [t removeFromSuperview]; }];
        });
    }];
}
@end

#pragma mark - Trigger

@interface ZXTrigger : NSObject
+ (instancetype)shared;
- (void)attach;
@end
@implementation ZXTrigger
+ (instancetype)shared {
    static ZXTrigger *t; static dispatch_once_t o;
    dispatch_once(&o, ^{ t = [ZXTrigger new]; });
    return t;
}
- (void)attach {
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if (![s isKindOfClass:[UIWindowScene class]]) continue;
        for (UIWindow *w in ((UIWindowScene *)s).windows) {
            if (objc_getAssociatedObject(w, "zx_attached")) continue;
            UITapGestureRecognizer *g = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(open)];
            g.numberOfTapsRequired = 2;
            g.numberOfTouchesRequired = 3;
            g.cancelsTouchesInView = NO;
            [w addGestureRecognizer:g];
            objc_setAssociatedObject(w, "zx_attached", @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
    }
    ZXSyncFloat();
    [ZXScreenBorder sync];
    if (ZXBool(@"hud_enabled", YES) && !gHud) {
        gHud = [ZXHud new];
        [ZXKeyWindow() addSubview:gHud];
        [gHud start];
        [gHud applyTheme];
    }
}
- (void)open {
    if (gMenu) [ZXMenuView hide];
    else [ZXMenuView show];
}
@end

#pragma mark - Init

__attribute__((constructor)) static void ZXInit(void) {
    ZXLog(@"ZaloXposed v%@ by Quang Bao loaded in %@", kVersion, NSBundle.mainBundle.bundleIdentifier);
    ZXInstallHooks();
    NSNotificationCenter *nc = NSNotificationCenter.defaultCenter;
    void (^again)(NSNotification *) = ^(NSNotification *n) {
        ZXInstallHooks();
        [[ZXTrigger shared] attach];
    };
    [nc addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:again];
    [nc addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:again];
    [nc addObserverForName:@"ZXOpenMenu" object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
        if (gMenu) [ZXMenuView hide];
        else [ZXMenuView show];
    }];
}
