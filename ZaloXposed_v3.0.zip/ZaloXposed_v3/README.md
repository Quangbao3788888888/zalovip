# ZaloXposed v3.0 — by Quang Bảo

© 2026 Quang Bảo. Bảo lưu mọi quyền.

## Tính năng chính

### Giao diện
- Menu kính mờ (Glassmorphism) cao cấp
- 4 theme: Rainbow, Neon Cyber, Dark Premium, Cherry Blossom
- Viền neon / 7 màu có animation
- Nút nổi Z kéo thả + hiệu ứng glow
- Bảng thông tin (HUD): FPS, Thời gian, RAM, Pin

### Chống theo dõi
- Tắt Firebase Analytics
- Chặn domain analytics / tracking (có thể chỉnh sửa danh sách)
- Nhật ký hoạt động chi tiết

### Tiện ích
- Import / Export cài đặt
- Đặt lại mặc định
- Kiểm tra phiên bản & môi trường
- Disclaimer rõ ràng

## Cách mở menu
- Bấm nút nổi **Z**
- Hoặc chạm **2 lần bằng 3 ngón tay** trong Zalo

## Build

### Không cần Mac
1. Đẩy lên GitHub
2. Actions → Build dylib
3. Tải artifact `ZaloXposed`

### Local (cần Xcode / Theos)
```bash
./build.sh
```

## Lưu ý quan trọng
- Chỉ dùng cho mục đích cá nhân, nghiên cứu.
- Không hỗ trợ vượt captcha, tạo tài khoản hàng loạt, anti-detect đăng ký.
- Zalo có thể cập nhật và làm một số hook hết hiệu lực.
- Người dùng tự chịu trách nhiệm.

## Phiên bản
- v3.0 — Full UI overhaul, theme system, enhanced HUD & logging, professional structure.
