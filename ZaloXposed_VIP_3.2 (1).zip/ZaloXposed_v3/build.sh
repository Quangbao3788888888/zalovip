#!/bin/bash
set -e
rm -rf build && mkdir -p build
SDK=$(xcrun --sdk iphoneos --show-sdk-path 2>/dev/null || echo "")
if [ -z "$SDK" ]; then
  echo "Warning: iPhoneOS SDK not found. Trying generic clang..."
  clang -arch arm64 -miphoneos-version-min=14.0 \
    -fobjc-arc -dynamiclib -framework UIKit -framework Foundation -framework CoreGraphics -framework QuartzCore \
    -install_name @rpath/ZaloXposed.dylib -o build/ZaloXposed.dylib src/Tweak.m || {
      echo "Build failed. Need proper iOS SDK / Theos environment."
      exit 1
    }
else
  xcrun -sdk iphoneos clang -arch arm64 -miphoneos-version-min=14.0 -isysroot "$SDK" \
    -fobjc-arc -dynamiclib -framework UIKit -framework Foundation -framework CoreGraphics -framework QuartzCore \
    -install_name @rpath/ZaloXposed.dylib -o build/ZaloXposed.dylib src/Tweak.m
fi

# Bundle resources
B=build/ZaloXposedRes.bundle
mkdir -p $B
cp -R Resources/*.lproj $B/ 2>/dev/null || true
cat > $B/Info.plist << 'PL'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>com.quangbao.zaloxposed.res</string>
<key>CFBundleName</key><string>ZaloXposedRes</string>
<key>CFBundlePackageType</key><string>BNDL</string>
</dict></plist>
PL

echo "Build done:"
ls -la build
