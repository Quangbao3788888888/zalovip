# ZaloXposed VIP 3.2 — by QBao

© 2026 by QBao. Bảo lưu mọi quyền.

## 20 nâng cấp trong bản 3.2

1. Tìm nhanh cài đặt trong menu.
2. Thu gọn/mở rộng từng nhóm cài đặt.
3. Chế độ giao diện gọn.
4. Điều chỉnh độ trong của bảng menu.
5. Tắt hiệu ứng chuyển động trang trí.
6. Phản hồi rung khi thao tác.
7. Chủ đề Ocean Blue.
8. Chủ đề Forest Green.
9. Lưu vị trí nút nổi sau khi kéo.
10. Hút nút nổi vào mép màn hình.
11. Làm mờ nút nổi khi không thao tác.
12. Lưu vị trí HUD.
13. Hiển thị thời lượng phiên Zalo.
14. Chọn đồng hồ 12/24 giờ.
15. Tùy chọn cập nhật HUD mỗi giây thay vì 2 lần/giây.
16. Cảnh báo một lần khi pin xuống 20%.
17. Ẩn tên miền khỏi nhật ký theo mặc định.
18. Tự dọn log cũ hơn 7 ngày.
19. Kiểm tra định dạng và giá trị khi nhập cài đặt JSON.
20. Màn hình chẩn đoán cục bộ, không đọc nội dung chat.

Các chức năng trước đó vẫn có: 4 theme gốc, viền màn hình, nút nổi, HUD FPS/RAM/pin, nhật ký, xuất/nhập và đặt lại cài đặt.

## Cách mở menu
- Bấm nút nổi **Z**
- Hoặc chạm **2 lần bằng 3 ngón tay** trong Zalo

## Build bằng GitHub Actions
1. Đẩy source hoặc file zip lên repo
2. Vào tab **Actions** → **Run workflow**
3. Tải artifact **ZaloXposed**

## Lưu ý
- Đây là tweak iOS chạy trong ứng dụng bên thứ ba; có thể không tương thích với mọi phiên bản Zalo/iOS.
- Chặn domain có thể làm một số chức năng phụ thuộc dịch vụ đó ngừng hoạt động; chỉ chỉnh danh sách khi hiểu tác động.
- Chỉ dùng cho mục đích cá nhân, nghiên cứu và bảo vệ quyền riêng tư; không thêm tính năng sửa tin nhắn, né xác thực hoặc vượt cơ chế bảo vệ.
- Người dùng tự chịu trách nhiệm.

**by QBao**
